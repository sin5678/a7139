/********************************************************************
*   UTI.h
*   function Definitions
*
********************************************************************/
#ifndef _UTI_H_
#define _UTI_H_

void Delay10us(Uint8);
void Delay100us(Uint8);
void Delay1ms(Uint8);
void Delay10ms(Uint8);

#endif
